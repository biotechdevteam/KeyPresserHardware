"use client"
import { useEffect, useState } from "react";
import { useRouter } from "next/navigation";

interface AuthState {
  isAuthenticated: boolean;
  user: null | { email: string; first_name: string; last_name: string }; // You can add more fields as needed
}

export const useAuth = () => {
  const [authState, setAuthState] = useState<AuthState>({
    isAuthenticated: false,
    user: null,
  });
  const router = useRouter();

  useEffect(() => {
    // Simulate a token check in localStorage or cookies
    const token = localStorage.getItem("token"); // You might use cookies or another storage solution

    if (token) {
      // Simulate token validation and fetch user info
      const user = JSON.parse(localStorage.getItem("user") || "{}");

      // Set authentication state to true and save user info
      setAuthState({
        isAuthenticated: true,
        user: user ? user : null,
      });
    } else {
      // User is not authenticated, set isAuthenticated to false
      setAuthState({
        isAuthenticated: false,
        user: null,
      });
    }
  }, []);

  const signOut = () => {
    localStorage.removeItem("token");
    localStorage.removeItem("user");
    setAuthState({ isAuthenticated: false, user: null });
    router.push("/auth/signin"); // Redirect to sign-in page after sign-out
  };

  return { ...authState, signOut };
};
